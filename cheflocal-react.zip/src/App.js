import React, { useState } from 'react';

function App() {
  const [nome, setNome] = useState('');
  const [logado, setLogado] = useState(false);
  const [avaliacoes, setAvaliacoes] = useState([]);
  const [chat, setChat] = useState(false);
  const [verPerfil, setVerPerfil] = useState(false);

  const chef = {
    nome: 'Tia Maria',
    local: 'Moçambique',
    tipo: 'Culinária Moçambicana',
    bio: 'Cozinheira de Maputo com 20 anos de tradição.',
    pratos: ['Arroz com feijão', 'Matapa', 'Frango à Zambeziana']
  };

  const enviarAvaliacao = () => {
    const comentario = prompt("Digite seu comentário:");
    if (comentario) {
      setAvaliacoes([...avaliacoes, comentario]);
    }
  };

  return (
    <div style={{ padding: 20, fontFamily: 'Arial' }}>
      <h1>🍲 ChefLocal</h1>

      {!logado ? (
        <div>
          <h2>Login</h2>
          <input
            value={nome}
            onChange={(e) => setNome(e.target.value)}
            placeholder="Digite seu nome"
          />
          <button onClick={() => setLogado(true)}>Entrar</button>
        </div>
      ) : (
        <div>
          <h2>Olá, {nome}!</h2>

          {!verPerfil ? (
            <>
              <div style={{ border: '1px solid #ccc', padding: 10, marginTop: 20 }}>
                <h3>Prato: Arroz com Feijão e Carne</h3>
                <p><strong>Chef:</strong> <span onClick={() => setVerPerfil(true)} style={{ textDecoration: 'underline', cursor: 'pointer' }}>{chef.nome}</span></p>
                <p><strong>Local:</strong> {chef.local}</p>
                <button onClick={() => setChat(true)}>Abrir Chat</button>
                <button onClick={enviarAvaliacao} style={{ marginLeft: 10 }}>Avaliar Prato</button>
              </div>

              {chat && (
                <div style={{ marginTop: 20, border: '1px solid gray', padding: 10 }}>
                  <h4>Chat com {chef.nome}</h4>
                  <p><strong>{chef.nome}:</strong> Olá! Como posso te ajudar? 😄</p>
                  <p><strong>Você:</strong> Oi! Como prepara esse prato?</p>
                  <button onClick={() => setChat(false)}>Fechar Chat</button>
                </div>
              )}

              <div style={{ marginTop: 20 }}>
                <h4>Avaliações:</h4>
                {avaliacoes.length === 0 ? (
                  <p>Sem avaliações ainda.</p>
                ) : (
                  <ul>
                    {avaliacoes.map((a, i) => (
                      <li key={i}>{a}</li>
                    ))}
                  </ul>
                )}
              </div>
            </>
          ) : (
            <div style={{ marginTop: 20, border: '1px solid #999', padding: 10 }}>
              <button onClick={() => setVerPerfil(false)}>← Voltar</button>
              <h3>Perfil de {chef.nome}</h3>
              <p><strong>Tipo:</strong> {chef.tipo}</p>
              <p><strong>Bio:</strong> {chef.bio}</p>
              <h4>Pratos:</h4>
              <ul>
                {chef.pratos.map((p, i) => <li key={i}>{p}</li>)}
              </ul>
            </div>
          )}
        </div>
      )}
    </div>
  );
}

export default App;